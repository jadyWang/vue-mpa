<template>
  <router-view></router-view>
</template>
<script>
import 'assets/common.scss'
</script>